import 'package:flutter/material.dart';

class AddVehicleController with ChangeNotifier {}
 