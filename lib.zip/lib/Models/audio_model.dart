// import 'package:just_audio/just_audio.dart';

// class AudioModel {
//   final AudioPlayer player = AudioPlayer();

//   AudioModel({ this.player = AudioPlayer()});
// }
