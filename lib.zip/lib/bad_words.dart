List<String> badWords = [];
